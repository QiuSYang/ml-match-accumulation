n=-1
n = n & 0xffffffff
print(n)